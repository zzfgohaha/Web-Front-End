function combineFilterFunc(config){
	return function(data){
		var lastArray = data;
		for(var prop in config){
			lastArray = config[prop](lastArray, state[prop]);
		}
		return lastArray;

	}
}

