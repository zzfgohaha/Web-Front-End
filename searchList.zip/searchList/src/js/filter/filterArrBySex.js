//根据按钮性别属性搜索列表
function filterArrBySex(data, sex){
	if(sex == 'a'){
		return data;
	}
	return data.filter(function(elem, index, self){
		return elem.sex == sex;
	});
}