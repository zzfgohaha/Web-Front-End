//根据输入框内容搜索列表中名字name相符合的对象
function filterArrByText(data, text){
	if(!text){
		return data;
	}
	return data.filter(function(elem, index, self){
		return elem.name.indexOf(text) != -1;
	});
}