var listArr = [
	{name: 'aaa', src: './src/img/1.jpg', description: 'haha', sex: 'f'},
	{name: 'aaa', src: './src/img/2.jpg', description: 'haha', sex: 'm'},
	{name: 'aaa', src: './src/img/3.jpg', description: 'haha', sex: 'f'},
	{name: 'bbb', src: './src/img/4.jpg', description: 'haha', sex: 'm'},
	{name: 'bbb', src: './src/img/5.jpg', description: 'haha', sex: 'f'}
];
var ul = document.getElementsByClassName('resultList')[0].getElementsByTagName('ul')[0];
var input = document.getElementsByTagName('input')[0];
// 调用[].slice.call()将类数组转换成数组
var btnArr = [].slice.call(document.getElementsByClassName('btn'));
var lastActiveBtn = document.getElementsByClassName('active')[0];
var state = {
	text: '',
	sex: 'a'
};
var lastFilterFunc = combineFilterFunc({text: filterArrByText, sex: filterArrBySex});



btnArr.forEach(function(elem, index, self){
	elem.onclick = function(){
		//change active for btn
		this.className = 'btn active';
		lastActiveBtn.className = 'btn';
		lastActiveBtn = this;

		state.sex = this.getAttribute('sex');
		renderPage(lastFilterFunc(listArr));
	}
})

input.oninput = function(){
	state.text = this.value;
	renderPage(lastFilterFunc(listArr));
}
function renderPage(data){
	var htmlStr = '';
	data.forEach(function(elem, index, self){
		htmlStr += '<li><img src="'+elem.src+'"></img><p class="name">'+elem.name+'</p><p class="description">'+elem.description+'</p></li>';
	});
	ul.innerHTML = htmlStr;
}
renderPage(listArr);